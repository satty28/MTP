# MTP
A Meshed Tree Protocol


#How to compile

sh install



#How to run

1) To start root  

	bash#	bin/mtpd 1 1

2) To start non root node

	bash#	bin/mtpd 0
